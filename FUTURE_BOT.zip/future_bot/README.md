# FUTURE BOT

Telegram bot that accepts public TikTok/Instagram video links and extracts the video's audio as MP3.

## Requirements
- Python 3.11+
- FFmpeg installed and available in PATH
- Telegram bot token from BotFather

## Install
```bash
pip install -r requirements.txt
```

## Run (Windows PowerShell)
```powershell
$env:BOT_TOKEN="YOUR_BOT_TOKEN"
python bot.py
```

## Run (Linux/macOS)
```bash
export BOT_TOKEN="YOUR_BOT_TOKEN"
python3 bot.py
```

Use only content you have permission to download/use. Private or restricted posts may fail.
