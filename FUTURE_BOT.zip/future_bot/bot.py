import os
import re
import asyncio
import tempfile
from pathlib import Path

import yt_dlp
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters

TOKEN = os.getenv('BOT_TOKEN', '').strip()
URL_RE = re.compile(r'https?://\S+')


def supported(url: str) -> bool:
    u = url.lower()
    return 'tiktok.com/' in u or 'instagram.com/' in u


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        '🎵 FUTURE BOT\n\nلینک عمومی TikTok یا Instagram رو بفرست تا صدای ویدیو رو به MP3 تبدیل کنم.'
    )


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('یک لینک عمومی TikTok یا Instagram بفرست.')


async def handle_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or '').strip()
    match = URL_RE.search(text)
    if not match:
        await update.message.reply_text('❌ لینک TikTok یا Instagram پیدا نشد.')
        return

    url = match.group(0).rstrip('.,!?)]}>')
    if not supported(url):
        await update.message.reply_text('❌ فعلاً فقط TikTok و Instagram پشتیبانی میشن.')
        return

    status = await update.message.reply_text('⏳ در حال استخراج آهنگ...')
    workdir = Path(tempfile.mkdtemp(prefix='future_bot_'))
    template = str(workdir / '%(id)s.%(ext)s')

    opts = {
        'format': 'bestaudio/best',
        'outtmpl': template,
        'noplaylist': True,
        'quiet': True,
        'no_warnings': True,
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
    }

    try:
        def download():
            with yt_dlp.YoutubeDL(opts) as ydl:
                return ydl.extract_info(url, download=True)

        info = await asyncio.to_thread(download)
        mp3s = list(workdir.glob('*.mp3'))
        if not mp3s:
            raise RuntimeError('MP3 was not created')

        title = (info.get('track') or info.get('title') or 'FUTURE BOT Audio')[:64]
        await status.edit_text('📤 آهنگ آماده شد؛ دارم می‌فرستم...')

        with mp3s[0].open('rb') as audio:
            await update.message.reply_audio(
                audio=audio,
                title=title,
                performer=info.get('artist') or info.get('uploader'),
                caption='🎵 FUTURE BOT',
            )
        await status.delete()
    except Exception as exc:
        print('ERROR:', repr(exc))
        await status.edit_text(
            '❌ نتونستم این ویدیو رو پردازش کنم.\n'
            'ممکنه خصوصی باشه یا سرویس اجازه دسترسی نداده باشه.'
        )
    finally:
        for p in workdir.glob('*'):
            try: p.unlink()
            except OSError: pass
        try: workdir.rmdir()
        except OSError: pass


def main():
    if not TOKEN:
        raise RuntimeError('BOT_TOKEN تنظیم نشده است.')
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler('start', start))
    app.add_handler(CommandHandler('help', help_cmd))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_link))
    print('FUTURE BOT is running...')
    app.run_polling()


if __name__ == '__main__':
    main()
